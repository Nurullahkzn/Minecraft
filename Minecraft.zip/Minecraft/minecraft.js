   
photoList = ['StoneNew.webp', 'StoneBricksNew.webp','SmoothQuartz.webp','SandstoneNew.webp','PrismarineNew.webp',
    'NetherQuartzOreNew.webp','IceNew.webp','Grimstone_JE1.webp','GraniteNew.webp','DioriteNew.webp','CopperBlockJE1.webp',
    'Copper_Ore_New.webp','CoalOreNew.webp','CobblestoneNew.webp','Bricks.webp','AndesiteNew.webp','NetherGoldOreNew.webp',
    'NewGoldOreText.webp','NewIronOreText.webp','NewLapisOreText.webp','BlockOfDiamondNew.webp','BlockOfEmeraldNew.webp',
    'BlockOfGoldNew.webp','DiamondOre.webp','RedstoneOreNew.webp','AncientDebris.webp','Crying_Obsidian.webp',
    'Obsidian.webp']

pickaxeList = ['Wooden_Pickaxe_JE3_BE3.webp','Stone_Pickaxe_JE2_BE2.webp','Golden_Pickaxe_JE4_BE3.webp','Iron_Pickaxe_JE3_BE2.webp','Diamond_Pickaxe_JE3_BE3.webp']

list = []

Information = {
    name: ['Wood-Pickaxe', 'Stone-Pickaxe','Golden-Pickaxe','Iron-Pickaxe','Diamond-Pickaxe'],

    damage: ['3', '4', '3', '5', '6'],
    
    durubility: ['60', '132', '33', '251', '1562'],

    speed:['Fifth','Fourth','Second','Third','Firsth'],
           
}

let index = 0
let degiss = 0
let score = 0

const btn2 = document.getElementById('btn2')
const photos2 = document.querySelector('.photos2')

function pickaxe(value1){ 
    if (degiss == 5) {
        degiss = 0
    }
    
    photos2.innerHTML = ''
    photos2.innerHTML += `
    <img src="Photos/pickaxe/${pickaxeList[degiss]}" />
    `

    degiss++;

    
    let name = document.querySelector('.name')
    let damage = document.querySelector('.damage')
    let durubility = document.querySelector('.durubility')
    let speed = document.querySelector('.speed')

    name.innerHTML += `${Information.name[degiss]}
    `
    damage.innerHTML += `${Information.damage[degiss]}
    `
    durubility.innerHTML += `${Information.durubility[degiss]}
    `
    speed.innerHTML += `${Information.speed[degiss]}
    `
    
}
document.getElementById("btn2").disable = true;


const btn = document.getElementById('btn')
const photos = document.querySelector('.photos','rainbowColor')

function blocks(value){ 
    if (degiss == 1){
        if (index == 14) {
            index = 0
        }
    
        photos.innerHTML = ''
        photos.innerHTML += `
        <img src="Photos/Blocks/${photoList[index]}" />
        `
        index++;
    }else if (degiss == 2){
        if (index == 18) {
            index = 0
        }
    
        photos.innerHTML = ''
        photos.innerHTML += `
        <img src="Photos/Blocks/${photoList[index]}" />
        `
        index++;
    }else if (degiss == 3){
        if (index == 16) {
            index = 0
        }
    
        photos.innerHTML = ''
        photos.innerHTML += `
        <img src="Photos/Blocks/${photoList[index]}" />
        `
        index++;
    }else if (degiss == 4){
        if (index == 25) {
            index = 0
        }
    
        photos.innerHTML = ''
        photos.innerHTML += `
        <img src="Photos/Blocks/${photoList[index]}" />
        `
        index++;
    }
    else if (degiss == 5){
        if (index == 28) {
            index = 0
        }
    
        photos.innerHTML = ''
        photos.innerHTML += `
        <img src="Photos/Blocks/${photoList[index]}" />
        `
        index++;
    }
    var r=Math.floor(Math.random()*255);
    var g=Math.floor(Math.random()*255);
    var b=Math.floor(Math.random()*255);
    
    var color=`rgb(${r} ,${g}, ${b})`;
    rainbowColor.style.background=color;





    let point = document.getElementById('number').value

    list.push(point)
    document.getElementById('number').value = ''

    console.log(...list)

    
}
function finish(){
    document.write(list.length*100)
} 